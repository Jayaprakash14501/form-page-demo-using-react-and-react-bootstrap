import React from "react";
import Table from 'react-bootstrap/Table';
import './Login.css'
export default function Datas(props){
    var datas=props.datas;
    return(
            <Table responsive>
                <thead>
                <tr>
                    <th>S.no</th>
                    <th>Name</th>
                    <th>Gender</th>
                    <th>Designation</th>
                    <th>Mail address</th>
                </tr>
                </thead>
                <tbody>
              {
                datas.map((data,index)=>(
                    <tr key={index}>
                        <td>{data.id}</td>
                        <td>{data.firstname} {data.lastname}</td>
                        <td>{data.gender}</td>
                        <td>{data.designation}</td>
                        <td>{data.mail}</td>
                    </tr>
                ))
              }
              </tbody>
            </Table>
        )
}