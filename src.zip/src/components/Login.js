import React, { useState } from 'react';
import './Login.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';
import Datas from './Datas';

export default function Login() {
    const [datas, setDatas] = useState([
        {
            id: 1,
            firstname: "Jaya",
            lastname: "Prakash",
            gender: "male",
            designation: "frontend",
            mail: "prakash@gmail.com"
        },
        {
            id: 2,
            firstname: "Anas",
            lastname: "Ahamed",
            gender: "male",
            designation: "backend",
            mail: "anas@gmail.com"
        }
    ]);

    const [newdatas, setNewdatas] = useState({
        firstname: "",
        lastname: "",
        gender: "",
        designation: "",
        mail: "",
        choose: false
    });

    const addItem = (item) => {
        const id = datas.length ? datas[datas.length - 1].id + 1 : 1;
        const obj = { id, ...item };
        setDatas([...datas, obj]);
    };

    const handleChange = (e) => {
        const { name, value, type, checked } = e.target;
        setNewdatas((prev) => ({
            ...prev,
            [name]: type === 'checkbox' ? checked : value
        }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        if (!newdatas.firstname || !newdatas.lastname || !newdatas.mail) {
            alert("Please fill in all required fields.");
            return;
        }
        addItem(newdatas);
        setNewdatas({
            firstname: "",
            lastname: "",
            gender: "",
            designation: "",
            mail: "",
            choose: false
        });
    };

    return (
        <div className="maindiv">
            <div className="formdiv">
                <h1>APPLICATION FORM</h1>
                <Form onSubmit={handleSubmit}>
                    <Container>
                        <Row>
                            <Col xs={12} sm={6}>
                                <Form.Label>First name</Form.Label>
                            </Col>
                            <Col xs={12} sm={6}>
                                <Form.Group controlId="formFirstname">
                                    <Form.Control 
                                        type="text" 
                                        placeholder="Enter First Name" 
                                        name="firstname" 
                                        value={newdatas.firstname} 
                                        onChange={handleChange} 
                                        required 
                                    />
                                </Form.Group>
                            </Col>
                        </Row>
                        <Row>
                            <Col xs={12} sm={6}>
                                <Form.Label>Last name</Form.Label>
                            </Col>
                            <Col xs={12} sm={6}>
                                <Form.Group controlId="formLastname">
                                    <Form.Control 
                                        type="text" 
                                        placeholder="Enter Last Name" 
                                        name="lastname" 
                                        value={newdatas.lastname} 
                                        onChange={handleChange} 
                                        required 
                                    />
                                </Form.Group>
                            </Col>
                        </Row>
                        <Row>
                            <Col xs={12} sm={6}>
                                <Form.Label>Gender</Form.Label>
                            </Col>
                            <Col xs={12} sm={6}>
                                <div>
                                    <Form.Check 
                                        inline 
                                        type="radio" 
                                        label="Male" 
                                        name="gender" 
                                        value="male" 
                                        checked={newdatas.gender === "male"} 
                                        onChange={handleChange} 
                                    />
                                    <Form.Check 
                                        inline 
                                        type="radio" 
                                        label="Female" 
                                        name="gender" 
                                        value="female" 
                                        checked={newdatas.gender === "female"} 
                                        onChange={handleChange} 
                                    />
                                    <Form.Check 
                                        inline 
                                        type="radio" 
                                        label="Others" 
                                        name="gender" 
                                        value="others" 
                                        checked={newdatas.gender === "others"} 
                                        onChange={handleChange} 
                                    />
                                </div>
                            </Col>
                        </Row>
                        <Row>
                            <Col xs={12} sm={6}>
                                <Form.Label>Designation</Form.Label>
                            </Col>
                            <Col xs={12} sm={6}>
                                <Form.Group controlId="formDesignation">
                                    <Form.Control 
                                        as="select" 
                                        name="designation" 
                                        value={newdatas.designation} 
                                        onChange={handleChange}
                                    >
                                        <option value="">--Choose anyone--</option>
                                        <option value="frontend">Frontend Developer</option>
                                        <option value="backend">Backend Developer</option>
                                        <option value="database">Database</option>
                                    </Form.Control>
                                </Form.Group>
                            </Col>
                        </Row>
                        <Row>
                            <Col xs={12} sm={6}>
                                <Form.Label>Email</Form.Label>
                            </Col>
                            <Col xs={12} sm={6}>
                                <Form.Group controlId="formEmail">
                                    <Form.Control 
                                        type="email" 
                                        placeholder="Enter Mail Address" 
                                        name="mail" 
                                        value={newdatas.mail} 
                                        onChange={handleChange} 
                                        required 
                                    />
                                </Form.Group>
                            </Col>
                        </Row>
                        <Row>
                            <Col xs={12} sm={12}>
                                <Form.Check 
                                    type="checkbox" 
                                    name="choose" 
                                    label="Terms and Conditions" 
                                    checked={newdatas.choose} 
                                    onChange={handleChange} 
                                />
                            </Col>
                        </Row>
                        <Row>
                            <Col xs={12} sm={12}>
                                <Button type="submit" className="logbutton" size="lg">Submit</Button>
                            </Col>
                        </Row>
                    </Container>
                </Form>
            </div>
            <div className="tabledata">
              <Datas datas={datas}/>
            </div>
        </div>
    );
}
